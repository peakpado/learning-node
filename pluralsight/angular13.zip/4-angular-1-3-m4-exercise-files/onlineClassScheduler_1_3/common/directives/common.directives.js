/**
 * Created by Deb on 10/16/2014.
 */
(function () {
    "use strict";

    angular
        .module("common.directives",[])
}());